__version__ = 0.316
from sherpa import main
main()