Test Huntington Disease dataset

Notes
------
Data Set Characteristics:

	:Number of Instances: 50
	
	:Number of Attributes: 75 numeric/categorical predictive
	
	:Attribute Information (in order):
		- CAGx	number of repeats observed at x count of CAG (in accordance with the reference sequence used)
		- CAGx+1	repeat for a range of x, x+1... x(max)
		- CAG75	the max value used in this set
		
	:Missing Attribute Values: None
	
	:Creator: Maxwell, A and Ciosi, M.