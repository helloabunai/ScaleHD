__all__ = ['__prediction.py', '__snpcalling.py']
from __prediction import AlleleGenotyping
from __snpcalling import DetermineMutations