__version__ = '1.0'
from sherpa import main
main()
