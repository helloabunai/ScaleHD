__all__ = ['__prediction.py', '__snpcalling.py']
from .__prediction import AlleleGenotyping
from .__snpcalling import DetermineMutations
from .__prediction import split_cag_target
