from .sherpa import *
__all__ = ['sherpa.py',
		   '__backend.py',
		   '__alleleface.py',
		   '__init__.py',
		   '__main__.py']
__author__='alastair.maxwell@glasgow.ac.uk'
__version__='1.0'
